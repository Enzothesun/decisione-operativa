Decisione Operativa – Ossigeno Liquido (Caserta & Salerno)
=============================================================

Contenuto
---------
- index.html  → pagina iniziale (scelta zona)
- caserta.html → strumento Caserta (tema scuro)
- salerno.html → strumento Salerno v1.2 (tema scuro)
- Questo README con istruzioni.

Pubblicazione su GitHub Pages (3 passi)
---------------------------------------
1) Crea un nuovo repository su GitHub (es: decisione-operativa).
2) Carica questi file nella root del repository.
3) Repository → Settings → Pages → "Deploy from a branch" → branch: main → folder: /root → Save.

Il sito sarà disponibile a un URL tipo:
https://<tuo-utente>.github.io/decisione-operativa/

Suggerimenti
------------
- Aggiorna i file localmente e ricaricali su GitHub per nuove versioni.
- Per link diretti alle zone: aggiungi /caserta.html o /salerno.html all'URL principale.
