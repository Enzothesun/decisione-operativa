
GitHub Pages – pacchetto 'decisione_operativa_gassoso'
====================================================

Contenuto:
- gassoso/index.html → pagina di ingresso (tema scuro) con reindirizzamento automatico
- gassoso/Decisione_Operativa_Ossigeno_Gassoso_v1_3.html → strumento completo

Pubblicazione (passi):
1) Estrai questo ZIP.
2) Vai sul repo GitHub 'decisione-operativa' → Add file → Upload files.
3) Trascina dentro **l'intera cartella 'gassoso'** e fai Commit.
4) GitHub Pages pubblicherà i file. I link saranno:
   - https://<utente>.github.io/decisione-operativa/gassoso/
   - https://<utente>.github.io/decisione-operativa/gassoso/Decisione_Operativa_Ossigeno_Gassoso_v1_3.html
